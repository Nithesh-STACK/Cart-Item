﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebApi.KaniniModel
{
    public partial class Logintbl
    {
        public string Userid { get; set; }
    }
}
