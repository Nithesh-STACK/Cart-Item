﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebApi.KaniniModel
{
    public partial class Logintabl
    {
        public string LoginId { get; set; }
        public string Password { get; set; }
    }
}
