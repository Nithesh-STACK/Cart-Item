﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AuthorizationService.KaniniModel
{
    public partial class Logintbl
    {
        public string Userid { get; set; }
    }
}
