﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AuthorizationService.KaniniModel
{
    public partial class Logintabl
    {
        public string LoginId { get; set; }
        public string Password { get; set; }
    }
}
