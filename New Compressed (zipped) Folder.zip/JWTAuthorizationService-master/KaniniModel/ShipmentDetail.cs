﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AuthorizationService.KaniniModel
{
    public partial class ShipmentDetail
    {
        public string BuyersName { get; set; }
        public int? Age { get; set; }
        public string AddressDetails { get; set; }
        public double MobileNumber { get; set; }
    }
}
